using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        map2 m;

        private void Form1_Load(object sender, EventArgs e)
        {
            m = new map2(125,125);
            propertyGrid1.SelectedObject = m;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            int s = 2;

            for (int x = 0; x < m.gameMap.GetLength(0); x++)
            {
                for (int y = 0; y < m.gameMap.GetLength(1); y++)
                {
                    if (m.gameMap[x, y] == 1)
                    {
                        e.Graphics.FillRectangle(new SolidBrush(Color.Beige), new Rectangle(x * s, y * s, s, s));
                    }

                    if (m.gameMap[x, y] == 2)
                    {
                        e.Graphics.FillRectangle(new SolidBrush(Color.Black), new Rectangle(x * s, y * s, s, s));
                    }

                }
            }

        }



        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            m.build();
            pictureBox1.Invalidate();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            m.reset();
            pictureBox1.Invalidate();
        }

    }
}