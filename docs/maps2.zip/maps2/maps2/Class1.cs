using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.ComponentModel;

namespace WindowsApplication1
{
    class map2
    {
        public int[,] gameMap;

        private Random r = new Random(1);

        public List<Rectangle> rooms = new List<Rectangle>();
        public List<Rectangle> corridors = new List<Rectangle>();

        private enum directions { north, east, south, west };

        private int roomHeightMax = 6;
        private int roomWidthMax = 6;
        private int roomHeightMin = 3;
        private int roomWidthMin = 3;
        private int minCorridorLength = 3;
        private int maxCorridorLength = 20;

        public int RoomHeightMax
        {
            get { return roomHeightMax; }
            set { roomHeightMax = value; }
        }

        public int RoomWidthMax
        {
            get { return roomWidthMax; }
            set { roomWidthMax = value; }
        }

        public int RoomHeightMin
        {
            get { return roomHeightMin; }
            set { roomHeightMin = value; }
        }

        public int RoomWidthMin
        {
            get { return roomWidthMin; }
            set { RoomWidthMin = value; }
        }

        public int MinCorridorLength
        {
            get { return minCorridorLength; }
            set { minCorridorLength = value; }
        }

        public int MaxCorridorLength
        {
            get { return maxCorridorLength; }
            set { maxCorridorLength = value; }
        }

        public int MaxRoom
        {
            get { return maxRoom; }
            set { maxRoom = value; }
        }

        private int roomCtr = 0;
        private int maxRoom = 20;


        private int pMakeCorridorOnCorridor=20;
        private int pMakeCorridorOnCorridorEnd=40;
        private int pMakeCorridorOnRoomEdge=60;
        private int pMakeRoomOnCorridor=80;
        private int pMakeRoomOnCorridorEnd = 100;

        [Category("Probabilities"), Description("Corridor on corridor")]
        public int MakeCorridorOnCorridor
        {
            get { return pMakeCorridorOnCorridor; }
            set { pMakeCorridorOnCorridor = value; }
        }
        [Category("Probabilities")]
        public int MakeCorridorOnCorridorEnd
        {
            get { return pMakeCorridorOnCorridorEnd; }
            set { pMakeCorridorOnCorridorEnd = value; }
        }
        [Category("Probabilities")]
        public int MakeCorridorOnRoomEdge
        {
            get { return pMakeCorridorOnRoomEdge; }
            set { pMakeCorridorOnRoomEdge = value; }
        }
        [Category("Probabilities")]
        public int MakeRoomOnCorridorEnd
        {
            get { return pMakeRoomOnCorridorEnd; }
            set { pMakeRoomOnCorridorEnd = value; }
        }
        [Category("Probabilities")]
        public int MakeRoomOnCorridor
        {
            get { return pMakeRoomOnCorridor; }
            set { pMakeRoomOnCorridor = value; }
        }




        public map2(int _width, int _height)
        {
            gameMap = new int[_width, _height];
        }

        public void reset()
        {
            gameMap = new int[gameMap.GetLength(0), gameMap.GetLength(1)];
            rooms.Clear();
            corridors.Clear();
        }
      
        private bool testPoint(Point _p)
        {
            if (_p.X >= 0 &
                    _p.X < gameMap.GetLength(0) &
                    _p.Y >= 0 &
                    _p.Y < gameMap.GetLength(1)
            )
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //These methods are used to get build points

            /// <summary>
            /// get a position of a random room's wall
            /// </summary>
            /// <param name="_direction">direction of wall, e.g. 0 for north (top), 
            /// 1 for east (right) etc</param>
            /// <returns>Point containing location</returns>
            private Point getRoomEdge(out int _direction)
            {
                Rectangle room = rooms[r.Next(0, rooms.Count)];
                _direction = getDirection();
                Point p = new Point();

                room.Inflate(1, 1);

                if (_direction == (int)directions.north)
                {
                    p = new Point(r.Next(room.Left + 1, room.Right), room.Top);
                }
                else if (_direction == (int)directions.east)
                {
                    p = new Point(room.Right, r.Next(room.Top + 1, room.Bottom));
                }
                else if (_direction == (int)directions.south)
                {
                    p = new Point(r.Next(room.Left + 1, room.Right), room.Bottom);
                }
                else if (_direction == (int)directions.west)
                {
                    p = new Point(room.Left, r.Next(room.Top + 1, room.Bottom));
                }

                return p;

            }
            
            // return the end point of a random corridor
            private Point getEndOfCorridor(out int _direction)
            {
                Rectangle c = corridors[r.Next(0, corridors.Count)];
                _direction = getDirection();
                Point p = new Point();

                if (r.Next(0, 2) == 0)
                {
                    p = new Point(c.Left, c.Top);
                }
                else
                {
                    p = new Point(c.Right, c.Top);
                }

                return p;
            }

            //return any point on a random corridor
            private Point getCorridorPoint()
            {
                Rectangle c = corridors[r.Next(0, corridors.Count)];
                return new Point(r.Next(c.Left, c.Right), r.Next(c.Top, c.Bottom));
            }

            //Return a rectangle representing a corridor using the provided values
            private Rectangle getCorridor(Point _p, int _direction)
            {
                int length = getCorridorLength();
                Size size = new Size();

                if (_direction == (int)directions.north)
                {
                    _p.Offset(0, -length - 1);
                    size = new Size(0, length);
                }
                else if (_direction == (int)directions.east)
                {
                    _p.Offset(1, 0);
                    size = new Size(length, 0);
                }
                else if (_direction == (int)directions.south)
                {

                    _p.Offset(0, 1);
                    size = new Size(0, length);
                }
                else if (_direction == (int)directions.west)
                {
                    _p.Offset(-length - 1, 0);
                    size = new Size(length, 0);
                }

                return new Rectangle(_p, size);
            }

            //Return a rectangle representing a room using the provided values
            private Rectangle getRoom(Point _start, int _direction, out Point _door)
            {
                Point o = new Point();
                _door = _start;

                Size size = new Size(
                                    r.Next(roomWidthMin, roomWidthMax),
                                    r.Next(roomHeightMin, roomHeightMax)
                                        );

                if (_direction == (int)directions.north)
                {
                    _door.Offset(0, -1);
                    _start.Offset(0, -2);
                    o = new Point(_start.X - r.Next(1, size.Width),
                                    _start.Y - size.Height);
                }
                else if (_direction == (int)directions.east)
                {
                    _door.Offset(1, 0);
                    _start.Offset(2, 0);
                    o = new Point(_start.X,
                                    _start.Y - r.Next(1, size.Height));
                }
                else if (_direction == (int)directions.south)
                {
                    _door.Offset(0, 1);
                    _start.Offset(0, 2);
                    o = new Point(_start.X - r.Next(1, size.Width),
                                    _start.Y);
                }
                else if (_direction == (int)directions.west)
                {
                    _door.Offset(-1, 0);
                    _start.Offset(-2, 0);
                    o = new Point(_start.X - size.Width,
                                    _start.Y - r.Next(1, size.Height));
                }



                return new Rectangle(o, size);
            }

        //get some random values

            private int getDirection()
            {
                return r.Next(0, 4);
            }

            private int getCorridorLength()
            {
                return r.Next(minCorridorLength, maxCorridorLength);
            }

        //build structures

            //Called once at the beginning of the build procedure
            private void buildRoom()
            {
                Size roomSize = new Size(
                                    r.Next(roomWidthMin, roomWidthMax),
                                    r.Next(roomHeightMin, roomHeightMax)
                                        );

                Point roomLocation = new Point(gameMap.GetLength(0) / 2, gameMap.GetLength(1) / 2);

                Rectangle room = new Rectangle(roomLocation, roomSize);
                rooms.Add(room);
                buildRectangle(room);
            }
            
            //locate the end of a corridor, and attempt to build a corridor on it
            private void makeCorridorOnCorridorEnd()
            {
                for (int ctr = 0; ctr < r.Next(0,10); ctr++)
                {
                int direction = 0;
                Point p = getEndOfCorridor(out direction);

                Rectangle cr = getCorridor(p, direction);
                if (testRectangle(cr))
                {
                    corridors.Add(cr);
                    buildRectangle(cr);
                }
                }

            }
            
            //locate a random point on a corridor and try to build a corridor
            private void makeCorridorOnCorridor()
            {

                int direction = getDirection();
                Point p = getCorridorPoint();

                Rectangle cr = getCorridor(p,direction);
                if (testRectangle(cr))
                {
                    corridors.Add(cr);
                    buildRectangle(cr);
                }

            }

            //attempt to build a corridor on the side of a room
            private void makeCorridorOnRoomEdge()
            {

                int direction;
                Point p = getRoomEdge(out direction);

                Point door = p;

                Rectangle c = getCorridor(p, direction);
                if (testRectangle(c))
                {
                    corridors.Add(c);
                    buildRectangle(c);
                    gameMap[door.X, door.Y] = 2;
                }

            }

            //attempt to build a room off a random point on a corridor
            private void makeRoomOnCorridor()
            {
                //the offest of start is to move one point in the direction
                //the room is being built, to ensure it has a discrete entry point

                int direction = getDirection();
                Point start = getCorridorPoint();

                Point door = new Point();

                Rectangle room = getRoom(start, direction, out door);

                if (testRectangle(room))
                {
                    buildRectangle(room);
                    rooms.Add(room);
                    gameMap[door.X, door.Y] = 2;  //door code
                    roomCtr++;
                }
            }

            //attempt to build a room on the end of a corridor
            private void makeRoomOnCorridorEnd()
            {
                //the offest of _start is to move one point in the direction
                //the room is being built, to ensure it has a discrete entry point

                int direction = 0;
                Point start = getEndOfCorridor(out direction);
                Point door = new Point();

                Rectangle room = getRoom(start, direction, out door);

                if (testRectangle(room))
                {
                    buildRectangle(room);
                    rooms.Add(room);
                    gameMap[door.X, door.Y] = 2;  //door code
                    roomCtr++;
                }


            }

        /// <summary>
        /// This loop constructs the maze
        /// </summary>
        public void build()
        {
            roomCtr = 0;

            //get started
            buildRoom();
            makeCorridorOnRoomEdge();


            while (roomCtr < maxRoom)
            {
                int prob = r.Next(0, 100);
                //decide what to do
                if (prob < pMakeCorridorOnCorridor)
                {
                    makeCorridorOnCorridor();
                }
                else if (prob < pMakeCorridorOnCorridorEnd)
                {
                    makeCorridorOnCorridorEnd();
                }
                else if (prob < pMakeCorridorOnRoomEdge)
                {
                    makeCorridorOnRoomEdge();
                }
                else if (prob < pMakeRoomOnCorridor)
                {
                    makeRoomOnCorridor();

                }
                else if (prob < pMakeRoomOnCorridorEnd)
                {
                    makeRoomOnCorridorEnd();

                }
            }
        }



        //use the provided rectangle to hollow out a section of the map
        private void buildRectangle(Rectangle r)
        {

            for (int x = r.Left; x <= r.Right; x++)
            {
                for (int y = r.Top; y <= r.Bottom; y++)
                {
                    gameMap[x, y] = 1;
                }
            }
        }

        //test if the rectangle area is unnoccupied, i.e. contains no open cells
        private bool testRectangle(Rectangle r)
        {
            //Inflate the rectangle, to ensure no overlaps occur and
            //a border is established
            if (r.Width == 0)//is corridor
            {
                r.Inflate(1, 0);
            }
            else if (r.Height == 0)//is corridor
            {
                r.Inflate(0, 1);
            }
            else //is room
            {
                r.Inflate(1, 1);
            }

            try
            {

                for (int x = r.Left; x <= r.Right; x++)
                {
                    for (int y = r.Top; y <= r.Bottom; y++)
                    {
                        if (gameMap[x, y] == 1)
                            return false;
                    }
                }
            }
            catch
            {
                //out of boundary error                    
                return false;
            }

            return true;

        }

    }
}
