﻿using System;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Input;
using System.Text;

namespace SilverlightShadowCasting
{
    public partial class MainPage : UserControl
    {
        private const string MapString = @"
###########################################################
###########################################################
###########################################################
###<....#...........##....##........#####...####........###
###.....#............##...#..........##.....##.....##...###
###.....#.............##......#.......##....##....##....###
#######................##.....##.......##...###...#.....###
####....................############...##..##$..###.....###
###...........#...#...#................##...#####.......###
###.......#...............#.............##.....##.......###
###...........#...#...#.........................#.......###
#####.....#...............#................#....#.......###
###.###.......#...#...#.....................#...#.......###
###...###..................................##..##.......###
###...###..................................###.##.......###
###...###..................................###.##.......###
####....####........##.............#########..#........####
#####..............#####...##......................########
###########################################################
###########################################################
###########################################################
";

        private const char wallMap = '#';
        private const char wallRender = '█';
        private const char floorMap = '.';
        private const char floorRender = '◦';
        private const char playerRender = '@';
        private const char treasureMap = '$';
        private const char stairsMap = '<';

        private int width;
        private int height;
        private char[,] map;
        private int playerX;
        private int playerY;
        private bool hasTreasure;
        private bool hasWon;

        public MainPage()
        {
            InitializeComponent();
            InitializeGame();
            Render();
        }

        private void InitializeGame()
        {
            var lines = MapString.Split(new[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

            width = lines.Select(x => x.Length).Max();
            height = lines.Length;
            map = new char[width, height];

            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x)
                    map[x, y] = lines[height - y - 1][x];

            playerX = 3;
            playerY = 17;
            hasTreasure = false;
            hasWon = false;
        }

        private string RenderToString()
        {
            bool[,] lit = new bool[width, height];
            int radius = 9;
            ShadowCaster.ComputeFieldOfViewWithShadowCasting(
                playerX, playerY, radius,
                (x1, y1) => map[x1, y1] == wallMap,
                (x2, y2) => { lit[x2, y2] = true; });
            var sb = new StringBuilder();
            for (int y = height - 1; y >= 0; --y)
            {
                for (int x = 0; x < width; ++x)
                {
                    if (x == playerX && y == playerY)
                        sb.Append(playerRender);
                    else if (lit[x, y])
                    {
                        if (map[x, y] == wallMap)
                            sb.Append(wallRender);
                        else if (map[x, y] == floorMap)
                            sb.Append(floorRender);
                        else
                            sb.Append(map[x, y]);
                    }
                    else
                        sb.Append(' ');
                }
                sb.AppendLine();
            }
            return sb.ToString();
        }

        private void Render()
        {
            label1.Content = RenderToString();
        }

        private void UserControl_KeyDown(object sender, KeyEventArgs e)
        {
            int dx = 0;
            int dy = 0;

            switch (e.Key)
            {
                case Key.Up: dy = 1; break;
                case Key.Down: dy = -1; break;
                case Key.Left: dx = -1; break;
                case Key.Right: dx = 1; break;
                default: return;
            }

            if (map[playerX + dx, playerY + dy] != wallMap)
            {
                playerX += dx;
                playerY += dy;
                Render();
            }

            if (map[playerX, playerY] == treasureMap)
            {
                hasTreasure = true;
                map[playerX, playerY] = floorMap;
                label1.Content += "\nYou found the treasure! Now get back to the stairs.";
            }

            if (hasTreasure && !hasWon && map[playerX, playerY] == stairsMap)
            {
                hasWon = true;
                label1.Content += "\nYou escaped with the treasure!";
            }
        }
    }
}
