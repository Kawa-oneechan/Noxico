﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.ComponentModel;
using System.Collections;


namespace map
{

    [Serializable]
    public class game
    {
        int[,] map;
        Point player;
        Boolean vision = true;
        Point offset;
        Dictionary<string, Point> offsets;

        List<Point> sight;

        int visualRange = 10;

        public delegate void moveDelegate();
        public event moveDelegate playerMoved;

        //constructor
        public game()
        {
            map = new int[62, 62];
            player = new Point(9, 14);
            offset = new Point();
            offsets = new Dictionary<string, Point>();

            //enlcose the map
            for (int x = 0; x < mapXLimit; x++)
            {
                map[x, 0] = 1;
                map[x, mapYLimit - 1] = 1;
            }
            for (int y = 0; y < mapXLimit; y++)
            {
                map[0, y] = 1;
                map[mapXLimit - 1, y] = 1;
            }


            //draw a room
            for (int x = 0; x < 8; x++)
            {
                map[5 + x, 5] = 1;
                map[12, 5 + x] = 1;
                map[5 + x, 13] = 1;
                map[5, 5 + x] = 1;

                map[9, 13] = 0; //room entrance
            }

            //coridoor
            for (int y = 13; y < 20; y++)
            {
                map[8, y] = 1;
                map[10, y] = 1;
            }

            map[9, 13] = 0; //room entrance

            offsets.Add("w", new Point(0, -1));
            offsets.Add("x", new Point(0, 1));
            offsets.Add("a", new Point(-1, 0));
            offsets.Add("d", new Point(1, 0));
            offsets.Add("q", new Point(-1, -1));
            offsets.Add("e", new Point(1, -1));
            offsets.Add("z", new Point(-1, 1));
            offsets.Add("c", new Point(1, 1));

        }



        public int playerX
        {
            get { return player.X; }
            set { player.X = value; }
        }

        public int playerY
        {
            get { return player.Y; }
            set { player.Y = value; }
        }

        public List<Point> Sight
        {
            get { return sight; }
        }

        public int mapXLimit
        {
            get { return map.GetLength(0); }
        }

        public int mapYLimit
        {
            get { return map.GetLength(1); }
        }

        public void movePlayer(string _direction)
        {
            try
            {
                //look up the offset
                offset = offsets[_direction];

                //check to see if the destination cell legal and reachable
                //if it ain't legal we get an error
                if (map[player.X + offset.X, player.Y + offset.Y] == 0)
                    player.Offset(offset);
            }
            catch (Exception ex)
            {
                return;
            }

            if (vision)
            {
                calculateSight();
            }

            if (playerMoved != null)
                playerMoved();

        }

        /// <summary>
        /// Go through all the octants
        /// </summary>
        public void calculateSight()
        {
            sight = new List<Point>();

            for (int octant = 1; octant < 9; octant++)
            {
                scan(1, octant, 1.0, 0.0);
            }

        }

        //is the cell within vision distance and does it match the provided state
        private bool testCell(int _x, int _y, int _cellState, int _depth)
        {
            try
            {
                if (!isVisible(player.X, player.Y, _x, _y)) throw new Exception();
                return map[_x, _y] == _cellState;
            }
            catch
            {
                return false;
            }
        }

        public int getMapPoint(int _x, int _y)
        {
            return map[_x, _y];
        }

        public void setMapPoint(int _x, int _y, int _val)
        {
            try
            {
                map[_x, _y] = _val;
            }
            catch { }
        }

        private double getSlope(double _x1, double _y1, double _x2, double _y2)
        {
            return (_x1 - _x2) / (_y1 - _y2);
        }

        private double getSlopeInv(double _x1, double _y1, double _x2, double _y2)
        {
            return (_y1 - _y2) / (_x1 - _x2);
        }

        protected void scan(int _depth, int _octant, double _startSlope, double _endSlope)
        {
            int x = 0;
            int y = 0;

            switch (_octant)
            {
                case 1:
                    y = player.Y - _depth;
                    x = player.X - Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlope(x, y, player.X, player.Y) >= _endSlope)
                    {
                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1) //cell blocked
                            {

                                //if prior open AND within range
                                if (testCell(x - 1, y, 0, _depth))
                                {
                                    //recursion
                                    scan(_depth + 1, _octant, _startSlope, getSlope(x - .5, y + 0.5, player.X, player.Y));
                                }

                            }
                            else //not blocked
                            {
                                //if prior closed AND within range
                                if (testCell(x - 1, y, 1, _depth))
                                {
                                    _startSlope = getSlope(x - .5, y - 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        x++;

                    }
                    x--; //we step back as the last step of the while has taken us past the limit

                    break;

                case 2:

                    y = player.Y - _depth;
                    x = player.X + Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlope(x, y, player.X, player.Y) <= _endSlope)
                    {
                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1)
                            {
                                if (testCell(x + 1, y, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlope(x + 0.5, y + 0.5, player.X, player.Y));
                                }
                            }
                            else
                            {
                                if (testCell(x + 1, y, 1, _depth))
                                {
                                    _startSlope = -getSlope(x + 0.5, y - 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        x--;

                    }
                    x++;

                    break;


                case 3:

                    x = player.X + _depth;
                    y = player.Y - Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlopeInv(x, y, player.X, player.Y) <= _endSlope)
                    {

                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1) //cell blocked
                            {
                                //if prior open AND within range
                                if (testCell(x, y - 1, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlopeInv(x - 0.5, y - 0.5, player.X, player.Y));
                                }
                            }
                            else //not blocked
                            {
                                //if prior closed AND within range
                                if (testCell(x, y - 1, 1, _depth))
                                {
                                    _startSlope = -getSlopeInv(x + 0.5, y - 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        y++;

                    }
                    y--; //we step back as the last step of the while has taken us past the limit

                    break;

                case 4:

                    x = player.X + _depth;
                    y = player.Y + Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;;

                    while (getSlopeInv(x, y, player.X, player.Y) >= _endSlope)
                    {

                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1)
                            {

                                if (testCell(x, y + 1, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlopeInv(x - 0.5, y + 0.5, player.X, player.Y));
                                }
                            }
                            else
                            {

                                if (testCell(x, y + 1, 1, _depth))
                                {
                                    _startSlope = getSlopeInv(x + 0.5, y + 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        y--;

                    }
                    y++;

                    break;

                case 5:

                    y = player.Y + _depth;
                    x = player.X + Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlope(x, y, player.X, player.Y) >= _endSlope)
                    {
                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1)
                            {

                                if (testCell(x + 1, y, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlope(x + 0.5, y - 0.5, player.X, player.Y));
                                }
                            }
                            else
                            {
                                if (testCell(x + 1, y, 1, _depth))
                                {
                                    _startSlope = getSlope(x + 0.5, y + 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        x--;

                    }
                    x++;

                    break;

                case 6:

                    y = player.Y + _depth;
                    x = player.X - Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlope(x, y, player.X, player.Y) <= _endSlope)
                    {
                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1)
                            {

                                if (testCell(x - 1, y, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlope(x - 0.5, y - 0.5, player.X, player.Y));
                                }
                            }
                            else
                            {
                                if (testCell(x - 1, y, 1, _depth))
                                {
                                    _startSlope = -getSlope(x - 0.5, y + 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        x++;

                    }
                    x--;

                    break;

                case 7:

                    x = player.X - _depth;
                    y = player.Y + Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlopeInv(x, y, player.X, player.Y) <= _endSlope)
                    {
                        Console.WriteLine(String.Format("x:{0}, y:{1}", x, y));

                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1)
                            {
                                if (testCell(x, y + 1, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlopeInv(x + 0.5, y + 0.5, player.X, player.Y));
                                }
                            }
                            else
                            {
                                if (testCell(x, y + 1, 1, _depth))
                                {
                                    _startSlope = getSlopeInv(x - 0.5, y + 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        y--;

                    }
                    y++;
                    break;

                case 8:

                    x = player.X - _depth;
                    y = player.Y - Convert.ToInt32((_startSlope * Convert.ToDouble(_depth)));

                    if (x < 0) break;
                    if (x >= mapXLimit) break;
                    if (y < 0) break;
                    if (y >= mapYLimit) break;

                    while (getSlopeInv(x, y, player.X, player.Y) >= _endSlope)
                    {

                        if (isVisible(player.X, player.Y, x, y))
                        {

                            if (map[x, y] == 1)
                            {
                                if (testCell(x, y - 1, 0, _depth))
                                {
                                    scan(_depth + 1, _octant, _startSlope, getSlopeInv(x + 0.5, y - 0.5, player.X, player.Y));
                                }
                            }
                            else
                            {
                                if (testCell(x, y - 1, 1, _depth))
                                {
                                    _startSlope = getSlopeInv(x - 0.5, y - 0.5, player.X, player.Y);
                                }
                                sight.Add(new Point(x, y));
                            }

                        }
                        y++;

                    }
                    y--;

                    break;


            }


            if (x < 0) x = 0;
            if (x >= mapXLimit) x = mapXLimit - 1;
            if (y < 0) y = 0;
            if (y >= mapYLimit) y = mapYLimit - 1;


            if (isVisible(player.X, player.Y, x, y) & map[x, y] == 0)
            {
                scan(_depth + 1, _octant, _startSlope, _endSlope);
            }


        }

        //See if the provided points are within visual range
        protected bool isVisible(int _x1, int _y1, int _x2, int _y2)
        {
            try
            {
                int i = map[_x1, _y1];  //illegal values throw an error
                i = map[_x2, _y2];

                if (_x1 == _x2) //if they're on the same axis, we only need to test one
                //value, which is computationaly cheaper than what we do below
                {
                    return Math.Abs(_y1 - _y2) <= visualRange;
                }

                if (_y1 == _y2)
                {
                    return Math.Abs(_x1 - _x2) <= visualRange;
                }

                return (Math.Pow((_x1 - _x2), 2) + Math.Pow((_y1 - _y2), 2)) <= Math.Pow(visualRange, 2);
            }
            catch
            {
                return false;
            }
        }

    }


}
