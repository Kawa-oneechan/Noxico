﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace map
{

    //http://roguebasin.roguelikedevelopment.org/index.php?title=FOV_using_recursive_shadowcasting_-_improved

    //http://roguebasin.roguelikedevelopment.org/index.php?title=FOV_using_recursive_shadowcasting

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        game g;
        Boolean mouseDown;

        private void Form1_Load(object sender, EventArgs e)
        {
            g = new game();
            g.playerMoved += new game.moveDelegate(g_PlayerMoved);
            pictureBox1.Focus();
            
        }

        void g_PlayerMoved()
        {
            pictureBox1.Invalidate();
            playerPosition.Text = String.Format("Player: {0},{1}", g.playerX, g.playerY);
        }
     



        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            g.movePlayer(e.KeyChar.ToString().ToLower());
        }



        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

            try
            {
                //draw the map
                for (int x = 0; x < g.mapXLimit; x++)
                {
                    for (int y = 0; y < g.mapYLimit; y++)
                    {
                        if (g.getMapPoint(x, y) > 0)
                            e.Graphics.FillRectangle(new SolidBrush(Color.Black), new Rectangle(x * 4, y * 4, 4, 4));
                    }
                }


                //draw the player
                e.Graphics.FillRectangle(new SolidBrush(Color.White), new Rectangle(g.playerX * 4, g.playerY * 4, 4, 4));

                //draw player sight
                foreach (Point p in g.Sight)
                {
                    e.Graphics.FillRectangle(new SolidBrush(Color.Blue), new Rectangle(p.X * 4, p.Y * 4, 4, 4));
                }


            }
            catch { }

        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            g = new game();
        }

        //private void saveToolStripButton_Click(object sender, EventArgs e)
        //{
        //    Stream stream = File.Open("foobar.stuff", FileMode.Create);
        //    BinaryFormatter bFormatter = new BinaryFormatter();
        //    bFormatter.Serialize(stream, g);
        //    stream.Close();   
        //}

        //private void openToolStripButton_Click(object sender, EventArgs e)
        //{
        //    Stream stream = File.Open("foobar.stuff", FileMode.Open);
        //    BinaryFormatter bFormatter = new BinaryFormatter();
        //    g = (game)bFormatter.Deserialize(stream);
        //    stream.Close();
        //}

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            pictureBox1.Invalidate();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                int x = e.X / 4;
                int y = e.Y / 4;

                if (e.Button == MouseButtons.Left)
                    g.setMapPoint(x, y,1);
                else
                    g.setMapPoint(x, y, 0);

                
                g.calculateSight();
                pictureBox1.Invalidate();
            }

            mousePosition.Text = String.Format("Mouse: {0},{1}", e.X / 4, e.Y / 4);
        }



        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }


    }
}
